//
//  CustomCell.swift
//  UITableViewCell
//
//  Created by Nhat (Norman) H.M. VU on 10/18/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {

    @IBOutlet weak var bodyLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
