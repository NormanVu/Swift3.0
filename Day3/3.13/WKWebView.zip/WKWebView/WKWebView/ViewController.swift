//
//  ViewController.swift
//  WKWebView
//
//  Created by Nhat (Norman) H.M. VU on 10/26/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate  {

    let webView = WKWebView(frame: .zero, configuration: WKWebViewConfiguration())

    lazy var backButton: UIBarButtonItem = {
        return UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(ViewController.backButtonTapped(_:)))
    }()
    lazy var forwardButton: UIBarButtonItem = {
        return UIBarButtonItem(title: "Forward", style: .plain, target: self, action: #selector(ViewController.forwardButtonTapped(_:)))
    }()
    lazy var reloadButton: UIBarButtonItem = {
        return UIBarButtonItem(title: "Reload", style: .plain, target: self, action: #selector(ViewController.reloadButtonTapped(_:)))
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.webView.navigationDelegate = self
        view.addSubview(webView)
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addConstraints([
            NSLayoutConstraint(item: webView, attribute: .top, relatedBy: .equal, toItem: view, attribute: .top, multiplier: 1, constant: 20),
            NSLayoutConstraint(item: webView, attribute: .right, relatedBy: .equal, toItem: view, attribute: .right, multiplier: 1, constant: 0),
            NSLayoutConstraint(item: webView, attribute: .left, relatedBy: .equal, toItem: view, attribute: .left, multiplier: 1, constant: 0),
            NSLayoutConstraint(item: webView, attribute: .bottom, relatedBy: .equal, toItem: view, attribute: .bottom, multiplier: 1, constant: 44)
            ])
        self.view.layoutIfNeeded()

        loadData()

        updateUI()
    }

    private func loadData() {
        DispatchQueue.main.async {
            let url = URL(string: "https://github.com/apple")!
            let request = URLRequest(url: url)
            self.webView.load(request)
        }
    }

    private func updateUI() {
        navigationController?.isToolbarHidden = false
        backButton.isEnabled = false
        forwardButton.isEnabled = false
        toolbarItems = [backButton, forwardButton, reloadButton]

        //KVO for webView.canGoBack, webView.canGoForward
        [#keyPath(WKWebView.canGoBack),
         #keyPath(WKWebView.canGoForward),
         #keyPath(WKWebView.title)
            ].forEach { keyPath in
                webView.addObserver(self, forKeyPath: keyPath, options: [.new, .old], context: nil)
        }
    }

    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        switch (keyPath, change?[.newKey], change?[.oldKey]) {
        case ((#keyPath(WKWebView.canGoBack))?, let newVal as Bool, let oldVal as Bool) where newVal != oldVal:
            backButton.isEnabled =  newVal

        case ((#keyPath(WKWebView.canGoForward))?, let newVal as Bool, let oldVal as Bool) where newVal != oldVal:
            forwardButton.isEnabled =  newVal

        case ((#keyPath(WKWebView.title))?, let newVal as String, let oldVal as String) where newVal != oldVal:
            title = newVal

        default:
            break
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(.allow)
    }

    func backButtonTapped(_ sender: UIButton) {
        webView.goBack()
    }

    func forwardButtonTapped(_ sender: UIButton) {
        webView.goForward()
    }

    func reloadButtonTapped(_ sender: UIButton) {
        webView.reload()
    }
}

