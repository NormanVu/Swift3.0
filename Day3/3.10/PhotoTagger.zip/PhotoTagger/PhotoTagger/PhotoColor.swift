//
//  PhotoColor.swift
//  PhotoTagger
//
//  Created by Nhat (Norman) H.M. VU on 10/24/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import Foundation

struct PhotoColor {
    var red: Int?
    var green: Int?
    var blue: Int?
    var colorName: String?
}
