//
//  ViewController.swift
//  UserDefaultsSettings
//
//  Created by Nhat (Norman) H.M. VU on 10/23/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

let kUserDefault = UserDefaults.standard

class ViewController: UIViewController {

    @IBOutlet weak var name: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.name.text = kUserDefault.value(forKey: "fullName") as? String
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func saveButtonTapped(_ sender: UIButton) {
        kUserDefault.set("\(name.text ?? "Customer name")", forKey: "fullName")
    }
}

