//
//  CustomizedView.swift
//  CustomizationView
//
//  Created by Nhat (Norman) H.M. VU on 10/16/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class CustomizedView: UIView {

    //Init
    class func view() -> CustomizedView {
        return Bundle.main.loadNibNamed("CustomizedView", owner: nil, options: nil)?.last as! CustomizedView
    }

    // Called when using xib
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    @IBAction func tapOnButton(_ sender: UIButton) {
        print("tapped!")
    }

}
