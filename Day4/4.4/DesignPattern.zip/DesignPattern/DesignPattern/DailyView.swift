//
//  DailyView.swift
//  DesignPattern
//
//  Created by Nhat (Norman) H.M. VU on 10/26/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import Foundation
import UIKit

protocol DailyViewDelegate: class {
    func dailyView(view: DailyView, didTapClose button: UIButton)
}

class DailyView: UIView {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var dateLabel: UILabel!

    weak var delegate: DailyViewDelegate?

    @IBAction func closeButtonTapped(_ sender: UIButton) {
        delegate?.dailyView(view: self, didTapClose: sender)	
    }
}
