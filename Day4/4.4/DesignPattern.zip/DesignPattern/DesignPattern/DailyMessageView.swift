//
//  DailyMessageView.swift
//  DesignPattern
//
//  Created by Nhat (Norman) H.M. VU on 10/26/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import Foundation
import UIKit

protocol DailyMessageViewDelegate: DailyViewDelegate {
    func dailyView(view: DailyView)
}

class DailyMessageView: DailyView {

    class func view() -> DailyMessageView {
        return Bundle.main.loadNibNamed("DailyMessageView", owner: nil, options: nil)?.last as! DailyMessageView
    }
}
