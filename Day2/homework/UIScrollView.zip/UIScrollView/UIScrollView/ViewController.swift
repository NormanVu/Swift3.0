//
//  ViewController.swift
//  UIScrollView
//
//  Created by Nhat (Norman) H.M. VU on 10/18/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var scrollView: UIScrollView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.view.addSubview(scrollView)
        self.scrollView.addSubview(imageView)
        self.scrollView.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.scrollView.minimumZoomScale = 0.5
        self.scrollView.maximumZoomScale = 3
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Scroll view delegate
    func viewForZooming(in scrollView : UIScrollView) -> UIView? {
        for imageView in self.scrollView.subviews where imageView is UIImageView {
            return imageView
        }
        return nil
    }
}

