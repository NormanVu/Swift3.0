//
//  ViewController.swift
//  UITableViewCustomization
//
//  Created by Nhat (Norman) H.M. VU on 10/18/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        self.tableView.delegate = self
        self.tableView.dataSource = self

        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")

    }

    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "cell")!
        cell.textLabel?.text = "(\(indexPath.row),\(indexPath.section))"
        return cell
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "\(section) section"
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let viewHeader = UIView(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        viewHeader.backgroundColor = .red
        viewHeader.alpha = 0.5
        return viewHeader
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let viewFooter = UIView(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        viewFooter.backgroundColor = .green
        return viewFooter
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let tableViewController = storyboard?.instantiateViewController(withIdentifier: "TableViewController") as? TableViewController else {
            return
        }
        tableViewController.delegate = self
        navigationController?.pushViewController(tableViewController, animated: true)
    }
}

extension ViewController: TableViewControllerDelegate {
    func closeViewController(_ viewController: TableViewController, didTapBackButton button: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
}
