//
//  ViewController.swift
//  UIViewSample
//
//  Created by Nhat (Norman) H.M. VU on 10/16/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        //UILabel
        let label = UILabel(frame: CGRect(x: 36, y: 30, width: 100, height: 20))
        label.text = "Label"
        self.view.addSubview(label)

        //UIButton
        let button = UIButton(frame: CGRect(x: 15, y: 80, width: 100, height: 20))
        button.setTitle("Button", for: UIControlState.normal)
        button.setTitleColor(UIColor(red: 0, green: 0, blue: 255, alpha: 1), for: UIControlState.normal)
        self.view.addSubview(button)

        //UITextField
        let textField = UITextField(frame: CGRect(x: 36, y: 130, width: 100, height: 20))
        textField.backgroundColor = UIColor(red: 10, green: 10, blue: 10, alpha: 1)
        self.view.addSubview(textField)

        //UIImageView: first
        let imageView = UIImageView(frame: CGRect(x: 36, y: 180, width: 150, height: 150))
        imageView.image = UIImage(named: "ojisan")
        self.view.addSubview(imageView)

        //UIImageView: second
        let imageView2 = UIImageView(frame: CGRect(x: 200, y: 180, width: 150, height: 150))
        imageView2.image = UIImage(named: "ojisan")
        self.view.addSubview(imageView2)

        //UITextView
        let textView = UITextView(frame: CGRect(x: 36, y: 350, width: 250, height: 100))
        textView.text = "Lorem ipsum dolor sit er elit lamet, consectetaur cilliim adipisicing pech, sed do eiusmod tempor incididunt ut labore et dolore magna ali qua. Ut enim ad minim venom, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea"
        self.view.addSubview(textView)

        //Remove the first UIImageView
        for view in self.view.subviews {
            if (view.isKind(of: UIImageView)) {
                view.removeFromSuperview()
                break
            }
        }
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

