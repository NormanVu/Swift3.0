//
//  SecondViewController.swift
//  ExternalForceModal
//
//  Created by Nhat (Norman) H.M. VU on 10/12/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

protocol SecondViewControllerDelegate : class {
    func closeViewController(_ viewController: SecondViewController, didTapButton button: UIButton)
}

class SecondViewController: UIViewController {


    @IBOutlet weak var closeModal: UIButton!
    weak var delegate: SecondViewControllerDelegate?

    func closeViewController(_ viewController: SecondViewController, didTapButton button: UIButton) {
        dismiss(animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func tapOnCloseModalButton(_ sender: UIButton) {
        self.delegate?.closeViewController(self, didTapButton: sender)
    }
}
