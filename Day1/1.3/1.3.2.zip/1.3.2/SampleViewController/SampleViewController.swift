//
//  SampleViewController.swift
//  SampleViewController
//
//  Created by Nhat (Norman) H.M. VU on 10/11/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class SampleViewController: UIViewController {

    @IBOutlet weak var grayView : UIView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.grayView.backgroundColor = .red

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

    }

}
