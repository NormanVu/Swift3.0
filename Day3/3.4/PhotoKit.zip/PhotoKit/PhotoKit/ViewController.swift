//
//  ViewController.swift
//  PhotoKit
//
//  Created by Nhat (Norman) H.M. VU on 10/20/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit
import Photos

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var loadImageButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    var fetchResult: PHFetchResult<PHAsset>!

    var targetSize: CGSize {
        return CGSize(width: imageView.bounds.width,
                      height: imageView.bounds.height)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func loadImageButtonTapped(_ sender: UIButton) {
        let imagePickerVC = UIImagePickerController()
        //UIImagePickerControllerSourceType.savedPhotosAlbum
        imagePickerVC.sourceType  = .photoLibrary
        // Whether to enable editing of selected media
        imagePickerVC.allowsEditing = true

        // selectable media limitation. The default is photo only.
        imagePickerVC.mediaTypes = UIImagePickerController.availableMediaTypes(for: imagePickerVC.sourceType)!
        imagePickerVC.delegate = self
        present(imagePickerVC, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        //Get URL image
        if let imageURL = info[UIImagePickerControllerReferenceURL] as? URL {
            fetchResult = PHAsset.fetchAssets(withALAssetURLs: [imageURL], options: nil)
        }

        //Request image to display
        if let photo = fetchResult.firstObject {
            // retrieve the image for the first result
            let imageManager = PHImageManager.default()
            imageManager.requestImage(for: photo, targetSize: targetSize, contentMode: .aspectFill, options: nil, resultHandler: {(image, info) -> Void in
                self.imageView.image = image //here is the image
            })
        }
        dismiss(animated: true, completion: nil)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}

