//
//  ViewController.swift
//  AutoLayoutSample
//
//  Created by Nhat (Norman) H.M. VU on 10/16/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    private var greenView: UIView = UIView()
    @IBOutlet weak var brownView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        //Change layout constraint by code
        self.greenView.backgroundColor = .green
        // AutoresizingMask is automatically converted to constant, so set it to false.
        self.greenView.translatesAutoresizingMaskIntoConstraints = false
        brownView.addSubview(greenView)
        // add constraint to greenView
        brownView.addConstraints([
            // The top of the greenView is located at the + 50 * 1 position from the top of the brownView.
            NSLayoutConstraint(item : greenView, attribute : .top , relatedBy : .equal , toItem : brownView, attribute : .top , multiplier : 1 , constant : 50),
            // left of greenView is viewed from the left of brownView, + 50 * 1 position.
            NSLayoutConstraint(item : greenView, attribute : .left , relatedBy : .equal , toItem : brownView, attribute : .left , multiplier : 1 , constant : 50),
            // right of greenView is viewed from the right of brownView, -50 * 1 position.
            NSLayoutConstraint(item : greenView, attribute : .right , relatedBy : .equal , toItem : brownView, attribute : .right , multiplier : 1 , constant : -50),
            // bottom of greenView is viewed from the bottom of brownView, -50 It becomes the position of * 1.
            NSLayoutConstraint(item: greenView, attribute: .bottom, relatedBy: .equal, toItem: brownView, attribute: .bottom, multiplier: 1, constant: -50)
            ])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

