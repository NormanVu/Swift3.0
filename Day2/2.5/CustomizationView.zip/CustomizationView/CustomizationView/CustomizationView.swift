//
//  CustomizationView.swift
//  CustomizationView
//
//  Created by Nhat (Norman) H.M. VU on 10/16/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class CustomizationView: UIView {

    private struct Const {
        static let subviewFrame = CGRect(x: 0, y: 300, width: 320, height: 200)
        static let labelFrame = CGRect(x: 10, y: 10, width: 320, height: 30)
    }

    // Constructor
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }

    // Required when using init
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    // When xib is used function is called
    override func awakeFromNib() {
        super.awakeFromNib()
        initializeView()
    }

    private func initializeView() {
        let subview = UIView(frame: Const.subviewFrame)
        subview.backgroundColor = .blue
        addSubview(subview)

        let label = UILabel(frame: Const.labelFrame)
        label.text = "Customization View"
        label.backgroundColor = .clear
        subview.addSubview(label)
    }

}
