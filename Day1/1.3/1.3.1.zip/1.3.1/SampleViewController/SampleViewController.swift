//
//  SampleViewController.swift
//  SampleViewController
//
//  Created by Nhat (Norman) H.M. VU on 10/11/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class SampleViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var button: UIButton!



    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.label.text = "Test"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func tapOnButton(_ sender: UIButton) {
        self.label.text = "Sample"
    }

}
