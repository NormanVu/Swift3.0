//
//  FourthViewController.swift
//  TabSample
//
//  Created by Nhat (Norman) H.M. VU on 10/12/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {
    init() {
        super.init(nibName: "FourthViewController", bundle: nil)
        tabBarItem.title = "Settings"
        tabBarItem.image = UIImage(named: "settings")
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
