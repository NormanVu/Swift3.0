//
//  ViewController.swift
//  UITextFieldUITextView
//
//  Created by Nhat (Norman) H.M. VU on 10/23/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit
//import NotificationCenter

class ViewController: UIViewController {

    @IBOutlet weak var countTextField: UILabel!
    @IBOutlet weak var countTextView: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var textView: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.textField.delegate = self
        self.textView.delegate = self

        //UITextField and UITextView will notify when text changed
        //NotificationCenter.default.addObserver(self, selector: #selector(ViewController.fieldEditorDidChange(_:)), name: NSNotification.Name.UITextFieldTextDidChange, object: nil)
        //NotificationCenter.default.addObserver(self, selector: #selector(ViewController.viewEditorDidChange(_:)), name: NSNotification.Name.UITextViewTextDidChange, object: nil)

        // Do any additional setup after loading the view, typically from a nib.
        self.countTextField.text = "\(textField.text?.characters.count ?? 0)"
        self.countTextView.text = "\(textView.text?.characters.count ?? 0)"

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    func fieldEditorDidChange(_ textField: UITextField) {
        self.countTextField.text = "\(textField.text?.characters.count ?? 0)"
    }
    func viewEditorDidChange(_ textView: UITextView) {
        self.countTextView.text = "\(textView.text?.characters.count ?? 0)"
    }*/
}


extension ViewController: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.countTextField.text = "\(textField.text?.characters.count ?? 0)"
    }

    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        self.countTextField.text = "0"
        return true
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.textField.resignFirstResponder()
        return true
    }
}

extension ViewController: UITextViewDelegate {
    func textViewDidEndEditing(_ textView: UITextView) {
        self.countTextView.text = "\(textView.text?.characters.count ?? 0)"
    }
    
    func textViewShouldClear(_ textView: UITextView) -> Bool {
        self.countTextView.text = "0"
        return true
    }

    func textViewShouldReturn(_ textView: UITextView) -> Bool {
        self.textView.resignFirstResponder()
        return true
    }
}
