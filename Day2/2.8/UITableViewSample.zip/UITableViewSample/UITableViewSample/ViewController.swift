//
//  ViewController.swift
//  UITableViewSample
//
//  Created by Nhat (Norman) H.M. VU on 10/17/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        //Set dataSource and delegate of tableView to self
        tableView.delegate  =  self
        tableView.dataSource  =  self

        //specify the class of the cell to be re-used
        tableView.register(UITableViewCell.self, forCellReuseIdentifier : "cellIdentifier")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 100
    }

    //TODO: - TODO
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "cellIdentifier")!
        cell.textLabel?.text = "\(indexPath.row)"

        return cell
    }
}

