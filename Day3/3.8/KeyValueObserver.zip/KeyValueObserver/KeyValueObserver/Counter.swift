//
//  Counter.swift
//  KeyValueObserver
//
//  Created by Nhat (Norman) H.M. VU on 10/23/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import Foundation

class Counter: NSObject {
    static let sharedCounter = Counter()

    dynamic var count: Int = 0

    private override init() {
        super.init()
    }
}
