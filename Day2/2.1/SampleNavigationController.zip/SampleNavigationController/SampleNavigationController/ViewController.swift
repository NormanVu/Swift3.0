//
//  ViewController.swift
//  SampleNavigationController
//
//  Created by Nhat (Norman) H.M. VU on 10/12/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        //Update title back button in NavigationBar
        let string: String
        if let count = navigationController?.viewControllers.count {
            string = "\(count)"
        } else {
            string = ""
        }
        title = string

        //Update background NavigationBar
        navigationController?.navigationBar.setBackgroundImage(UIImage(named: "customNavBarImage1"), for: .default)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func tapOnPushButton(_ sender: UIButton) {
        guard let viewController = storyboard?.instantiateViewController(withIdentifier: "ViewController") else {
            return
        }
        navigationController?.pushViewController(viewController, animated: true)
    }

    @IBAction func tapOnCloseButton(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
}

