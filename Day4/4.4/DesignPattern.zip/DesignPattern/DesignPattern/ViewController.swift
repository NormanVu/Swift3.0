//
//  ViewController.swift
//  DesignPattern
//
//  Created by Nhat (Norman) H.M. VU on 10/26/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var dailyView: DailyView?
    var dailyMessageView: DailyMessageView?
    var dailyChoiceView: DailyChoiceView?
    var dailyImageView: DailyImageView?


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func choiceViewButtonTapped(_ sender: UIButton) {
        //Show dialog choice view
        dailyChoiceView = DailyChoiceView.view()
        dailyChoiceView?.delegate = self
        dailyChoiceView?.translatesAutoresizingMaskIntoConstraints = false
        view?.addSubview(dailyChoiceView!)
        view.addConstraints([
            NSLayoutConstraint(item: dailyChoiceView as Any, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1, constant: 0),
            NSLayoutConstraint(item: dailyChoiceView as Any, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1, constant: 0),
            NSLayoutConstraint(item: dailyChoiceView as Any, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: (dailyChoiceView?.bounds.size.height)!),
            NSLayoutConstraint(item: dailyChoiceView as Any, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: (dailyChoiceView?.bounds.size.width)!)
            ])
        dailyView = dailyChoiceView
        self.view.layoutIfNeeded()
    }

    @IBAction func messageViewButtonTapped(_ sender: UIButton) {
        //Show dialog message view
        dailyMessageView = DailyMessageView.view()
        dailyMessageView?.delegate = self
        dailyMessageView?.translatesAutoresizingMaskIntoConstraints = false
        view?.addSubview(dailyMessageView!)
        view.addConstraints([
            NSLayoutConstraint(item: dailyMessageView as Any, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1, constant: 0),
            NSLayoutConstraint(item: dailyMessageView as Any, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1, constant: 0),
            NSLayoutConstraint(item: dailyMessageView as Any, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: (dailyMessageView?.bounds.size.height)!),
            NSLayoutConstraint(item: dailyMessageView as Any, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: (dailyMessageView?.bounds.size.width)!)
            ])
        dailyView = dailyMessageView
        self.view.layoutIfNeeded()
    }

    @IBAction func imageViewButtonTapped(_ sender: UIButton) {
        dailyImageView = DailyImageView.view()
        dailyImageView?.delegate = self
        dailyImageView?.translatesAutoresizingMaskIntoConstraints = false
        view?.addSubview(dailyImageView!)
        view.addConstraints([
            NSLayoutConstraint(item: dailyImageView as Any, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1, constant: 0),
            NSLayoutConstraint(item: dailyImageView as Any, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1, constant: 0),
            NSLayoutConstraint(item: dailyImageView as Any, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: (dailyImageView?.bounds.size.height)!),
            NSLayoutConstraint(item: dailyImageView as Any, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: (dailyImageView?.bounds.size.width)!)
            ])
        dailyView = dailyImageView
        self.view.layoutIfNeeded()
    }
    
}

extension ViewController: DailyViewDelegate {
    func dailyView(view: DailyView, didTapClose button: UIButton) {
        dailyView?.removeFromSuperview()
    }
}

extension ViewController: DailyChoiceViewDelegate {
    func dailyView(view: DailyView, didTapNo button: UIButton) {
        print("no tapped")
    }

    func dailyView(view: DailyView, didTapYes button: UIButton) {
        print("yes tapped")
    }
}



