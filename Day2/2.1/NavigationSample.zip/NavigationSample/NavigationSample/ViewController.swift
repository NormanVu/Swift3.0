//
//  ViewController.swift
//  NavigationSample
//
//  Created by Nhat (Norman) H.M. VU on 10/12/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var buttonA: UIButton!
    @IBOutlet weak var buttonB: UIButton!
    @IBOutlet weak var buttonC: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func tapOnButton(_ sender: UIButton) {
        let buttonString: String
        switch (sender) {
        case buttonA:
            buttonString = "Button A Tapped"
        case buttonB:
            buttonString = "Button B Tapped"
        case buttonC:
            buttonString = "Button C Tapped"
        default:
            return
        }

        guard let nextViewController = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as? NextViewController else {
            return
        }
        nextViewController.buttonString = buttonString
        navigationController?.pushViewController(nextViewController, animated: true)
    }

}
