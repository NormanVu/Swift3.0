//
//  SecondViewController.swift
//  SampleViewController
//
//  Created by Nhat (Norman) H.M. VU on 10/11/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    weak var delegate: SecondViewControllerDelegate?

    @IBOutlet weak var closeButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func tapOnCloseButton(_ sender: UIButton) {
        delegate?.secondViewController(self, didTapButton: closeButton)
    }

}
