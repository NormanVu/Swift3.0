//
//  ViewController.swift
//  SampleViewController
//
//  Created by Nhat (Norman) H.M. VU on 10/11/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let sampleVC: SampleViewController = SampleViewController(nibName: "SampleViewController", bundle: nil)

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        view.addSubview(sampleVC.view)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        sampleVC.view.frame = view.bounds
    }
}

