//
//  ViewController.swift
//  FileManager
//
//  Created by Nhat (Norman) H.M. VU on 10/20/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var readButton: UIButton!


    func fileURL() -> URL? {
        let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)

        guard let url = urls.first else { return nil }

        let newUrl = url.appendingPathComponent("file.dat")

        return newUrl
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        guard let fileUrl = fileURL(), FileManager.default.fileExists(atPath: fileUrl.path) else {
            print("not exist")
            return
        }
        guard let readDict = NSKeyedUnarchiver.unarchiveObject(withFile: fileUrl.path) as? [String : String] else { return }
        textField.text = readDict["textField"]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func saveButtonTapped(_ sender: UIButton) {
        guard let fileUrl = fileURL() else { return }
        let saveDict = ["textField" : "\(textField.text ?? "")"]
        if NSKeyedArchiver.archiveRootObject(saveDict, toFile: fileUrl.path) {
            print("save success")
        } else {
            print("failed")
        }
    }

    @IBAction func readButtonTapped(_ sender: UIButton) {
        guard let fileUrl = fileURL(), FileManager.default.fileExists(atPath: fileUrl.path) else {
            print("not exist")
            return
        }
        guard let readDict = NSKeyedUnarchiver.unarchiveObject(withFile: fileUrl.path) as? [String : String] else { return }
        textField.text = readDict["textField"]
        print("read success")
    }

    @IBAction func deleteButtonTapped(_ sender: UIButton) {
        guard let fileUrl = fileURL(), FileManager.default.fileExists(atPath: fileUrl.path) else {
            print("not exist")
            return
        }
        do {
            try FileManager.default.removeItem(atPath: fileUrl.path)
            print("delete success")
        } catch {
            print("failed")
        }
    }
}

