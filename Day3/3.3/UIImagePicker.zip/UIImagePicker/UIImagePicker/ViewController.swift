//
//  ViewController.swift
//  UIImagePicker
//
//  Created by Nhat (Norman) H.M. VU on 10/20/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func cameraButtonTapped() {
        let imagePickerVC = UIImagePickerController()
        //UIImagePickerControllerSourceType.savedPhotosAlbum
        imagePickerVC.sourceType  = .photoLibrary
        // Whether to enable editing of selected media
        imagePickerVC.allowsEditing = true

        // selectable media limitation. The default is photo only.
        imagePickerVC.mediaTypes = UIImagePickerController.availableMediaTypes(for: imagePickerVC.sourceType)!
        imagePickerVC.delegate = self
        present(imagePickerVC, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        dismiss(animated: true, completion: nil)
        self.imageView.image = info[UIImagePickerControllerOriginalImage] as? UIImage
    }
}
