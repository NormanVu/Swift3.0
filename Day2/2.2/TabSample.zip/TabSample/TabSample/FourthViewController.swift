//
//  FourthViewController.swift
//  TabSample
//
//  Created by Nhat (Norman) H.M. VU on 10/12/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {
    init() {
        //Crash app at run time after implementing new Fourth View Controller also create xib file at the same time.
        //super.init(nibName: "FourthViewController", bundle: nil)

        //Create another Fourth View (FourthView.xib) after creating new Fourth View Controller won't be crashed
        super.init(nibName: "FourthView", bundle: nil)
        tabBarItem.title = "Settings"
        tabBarItem.image = UIImage(named: "settings")
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
