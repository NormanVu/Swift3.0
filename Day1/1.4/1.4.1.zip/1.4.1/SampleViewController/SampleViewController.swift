//
//  SampleViewController.swift
//  SampleViewController
//
//  Created by Nhat (Norman) H.M. VU on 10/11/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

protocol SecondViewControllerDelegate : class {
    func  secondViewController(_ viewController : SecondViewController, didTapButton button : UIButton)
}

class SampleViewController: UIViewController, SecondViewControllerDelegate {

    //Properties
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var button: UIButton!

    //Delegate methods
    func secondViewController(_ viewController: SecondViewController, didTapButton button: UIButton) {
        dismiss(animated: true, completion: nil)
    }

    //Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.label.text = "Test"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Actions
    @IBAction func tapOnButton(_ sender: UIButton) {
        self.label.text = "Sample"
    }

    @IBAction func tapOnExercise1Button(_ sender: UIButton) {
        //Using Present Modally by drag segue from Exercise 1 button to SecondViewController
    }

    @IBAction func tapOnExercise2Button(_ sender: UIButton) {
        performSegue(withIdentifier: "SecondViewControllerIdentifier", sender: self)
    }

    @IBAction func tapOnExercise3Button(_ sender: UIButton) {
        let secondVC = storyboard?.instantiateViewController(withIdentifier : "SecondViewController") as! SecondViewController
        present(secondVC, animated: true, completion: nil)
    }

    @IBAction func tapOnExercise4Button(_ sender: UIButton) {
        let secondVC = storyboard?.instantiateViewController(withIdentifier : "SecondViewController") as! SecondViewController
        secondVC.delegate = self
        present(secondVC, animated: true, completion: nil)
    }
}
