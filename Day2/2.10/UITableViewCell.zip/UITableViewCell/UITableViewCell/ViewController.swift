//
//  ViewController.swift
//  UITableViewCell
//
//  Created by Nhat (Norman) H.M. VU on 10/18/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        self.tableView.delegate = self
        self.tableView.dataSource = self

        self.tableView.register(UINib(nibName: "CustomCell", bundle: nil), forCellReuseIdentifier: "cellIdentifier")
        self.tableView.register(UINib(nibName: "CustomCell2", bundle: nil), forCellReuseIdentifier: "cell2Identifier")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 125
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 100
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: CustomCell = CustomCell()
        if (indexPath.row % 2 == 0) {
            cell = self.tableView?.dequeueReusableCell(withIdentifier: "cellIdentifier") as! CustomCell
            cell.bodyLabel?.text = "\(indexPath.row)"
        } else {
            cell = self.tableView?.dequeueReusableCell(withIdentifier: "cell2Identifier") as! CustomCell
            cell.bodyLabel?.text = "\(indexPath.row)"
        }
        return cell
    }

}

