//
//  ViewController.swift
//  JSON
//
//  Created by Nhat (Norman) H.M. VU on 10/25/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var articles: [[String: String?]] = []
    let table = UITableView()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        title = "JSON"

        table.frame = view.frame
        view.addSubview(table)
        table.dataSource = self

        getArticles()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func getArticles() {
        Alamofire.request("https://qiita.com/api/v2/items", method: .get, parameters: nil, headers: [:])
            .responseJSON{response in
                guard let object = response.result.value else {
                    return
                }
                do {
                    let json = JSON(object)
                    DispatchQueue.main.async {
                        json.forEach { (_, json) in
                            let article: [String: String?] = [
                                "title": json["title"].string,
                                "userId": json["user"]["id"].string
                            ]
                            self.articles.append(article)
                        }
                        self.table.reloadData()
                    }
                } catch let e {
                    DispatchQueue.main.async {
                        print(e)
                    }
                }
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articles.count
    }

    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        let article = articles[indexPath.row]
        cell.textLabel?.text = article["title"]!
        cell.detailTextLabel?.text = article["userId"]!
        return cell
    }

}

