//
//  SampleViewController.swift
//  SampleViewController
//
//  Created by Nhat (Norman) H.M. VU on 10/11/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit


protocol SecondViewControllerDelegate : class {
    func secondViewController(_ viewController : SecondViewController, didTapButton button : UIButton)
}


class SampleViewController: UIViewController, SecondViewControllerDelegate {

    @IBOutlet weak var grayView : UIView!
    @IBOutlet weak var openButton: UIButton!

    //Delegate methods
    func secondViewController(_ viewController: SecondViewController, didTapButton button: UIButton) {
        dismiss(animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.grayView.backgroundColor = .red

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

    }

    @IBAction func tapOnOpenButton(_ sender: UIButton) {
        let secondVC: SecondViewController = SecondViewController(nibName: "SecondViewController", bundle: nil)
        secondVC.delegate = self
        present(secondVC, animated: true, completion: nil)
    }

}
