//
//  TagsColorTableData.swift
//  TagsColorTableData
//
//  Created by Nhat (Norman) H.M. VU on 10/24/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

struct TagsColorTableData {
  var label: String
  var color: UIColor?
}
