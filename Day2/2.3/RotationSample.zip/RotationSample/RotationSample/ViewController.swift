//
//  ViewController.swift
//  RotationSample
//
//  Created by Nhat (Norman) H.M. VU on 10/13/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit
import Foundation

let kPortraitBlueViewRect: CGRect = CGRect(x: 32.0, y: 18.0, width: 150.0, height: 150.0)
let kLandscapeBlueViewRect: CGRect = CGRect(x: 18.0, y: 32.0, width: 150.0, height: 150.0)
let kPortraitYellowViewRect: CGRect = CGRect(x: 32.0, y: 185.0, width: 150.0, height: 150.0)
let kLandscapeYellowViewRect: CGRect = CGRect(x: 185.0, y: 32.0, width: 150.0, height: 150.0)



class ViewController: UIViewController {

    @IBOutlet weak var blueView: UIView!
    @IBOutlet weak var yellowView: UIView!

    // [1] Rotation notice is notified to each ViewController from rootViewController
    // Each ViewController responds as to whether it corresponds to rotation
    // Rotate in the direction set in the project summary without
    // writing,if you write it, this setting takes precedence
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return [.portrait, .landscape]
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // [2] draw a view
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        print("will layout subviews")
    }

    // [3] pre-rotation processing
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if size.width > size.height {
            blueView.frame = kLandscapeBlueViewRect
            yellowView.frame = kLandscapeYellowViewRect
            print("to Landscape")
        } else {
            blueView.frame = kPortraitBlueViewRect
            yellowView.frame = kPortraitYellowViewRect
            print("to Portrait")
        }
    }

    // [4] If the traitCollection is changed, set any animation here
    override func willTransition(to newCollection: UITraitCollection, with coordinator: UIViewControllerTransitionCoordinator) {
        print("will change collection")
    }

    // [5] traitCollection change completion processing
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        print("did change collection")
    }
}

