//
//  ViewController.swift
//  KeyValueObserver
//
//  Created by Nhat (Norman) H.M. VU on 10/23/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var label: UILabel!

    deinit {
        Counter.sharedCounter.removeObserver(self, forKeyPath: #keyPath(Counter.count))
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        label.text = "\(Counter.sharedCounter.count)"

        //Register KVO for Counter.count variable
        Counter.sharedCounter.addObserver(self, forKeyPath: #keyPath(Counter.count), options: [.new, .old], context: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func pushButtonTapped(_ sender: UIButton) {
        guard let viewController = storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController else {
            return
        }
        navigationController?.pushViewController(viewController, animated: true)
    }

    @IBAction func countDownButtonTapped(_ sender: UIButton) {
        Counter.sharedCounter.count = max(0, Counter.sharedCounter.count - 1)

    }

    @IBAction func countUpButtonTapped(_ sender: UIButton) {
        Counter.sharedCounter.count += 1
    }

    //Get value when #keypath(Counter.count) is changed
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        switch (keyPath, change?[.newKey] as? Int) {
            case ((#keyPath(Counter.count))?, let newValue?):
                label.text = "\(newValue)"

            default:
                break
        }
    }

}

