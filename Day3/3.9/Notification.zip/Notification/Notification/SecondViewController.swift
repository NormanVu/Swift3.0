//
//  SecondViewController.swift
//  Notification
//
//  Created by Nhat (Norman) H.M. VU on 10/23/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var label: UILabel!

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(type(of: self).recieveNotification(_:)),
                                                   name: NSNotification.Name(rawValue: "postNotificationButtonTapped"),
                                                 object: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func recieveNotification(_ notification: Notification) {
        guard let value = notification.userInfo?["key"] as? String else { return }
        self.label?.text = value
    }
}

