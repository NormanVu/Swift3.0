//
//  ViewController.swift
//  AnimationSample
//
//  Created by Nhat (Norman) H.M. VU on 10/16/17.
//  Copyright © 2017 enclaveit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    private struct Const {
        static let ojisanMovedFrame = CGRect(x: 0, y: 286, width: 170, height: 170)

        static let ojisanInitialFrame = CGRect(x: 85, y: 115, width: 170, height: 170)
    }

    private var ojisanImageView1 : UIImageView?
    private var ojisanImageView2 : UIImageView?

    @IBOutlet weak var ojisanImageView : UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        // Do any additional setup after loading the view, typically from a nib.
        let ojisanImageView1 = UIImageView(image: UIImage(named: "ojisan"))
        ojisanImageView1.frame  = Const.ojisanInitialFrame
        view.addSubview (ojisanImageView1)
        self.ojisanImageView1  = ojisanImageView1

        let ojisanImageView2 = UIImageView(image: UIImage(named: "ojisan"))
        ojisanImageView2.frame = Const.ojisanInitialFrame
        view.addSubview(ojisanImageView2)
        ojisanImageView2.isHidden  =  true
        self.ojisanImageView2 = ojisanImageView2
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        //Animation by animate method
        UIView.animate(withDuration: 5, animations: {
            self.ojisanImageView.frame = Const.ojisanMovedFrame
        }, completion: nil)

        //Animation by transition method
        UIView.transition(with: view, duration: 3, options: .transitionCurlUp, animations: {
            self.ojisanImageView1?.isHidden = true
            self.ojisanImageView2?.isHidden = false
        }, completion: nil)
    }


}

